import React from 'react'

const DeleteButton = () => {
  return (
    <div>
      
    </div>
  )
}

export default DeleteButton
