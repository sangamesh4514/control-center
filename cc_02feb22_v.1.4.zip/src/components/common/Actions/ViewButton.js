import React from 'react'

const ViewButton = () => {
  return (
    <div>
      
    </div>
  )
}

export default ViewButton
