export const url = "https://ingendynamics.com";
export const rosUrl = "ws://ec2-54-176-28-246.us-west-1.compute.amazonaws.com:2005";
export const config =  {
  bucketName: "aidouserfiles",
  region: "us-east-2",
  accessKeyId: "AKIAVTMWQGEEKQ46K4FG",
  secretAccessKey: "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",
};
