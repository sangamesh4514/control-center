import React from 'react';

const Spinner = () => {
    return (
        <>
            <i class="fa fa-wrench faa-wrench animated"></i>
        </>
    )
}

export default Spinner;